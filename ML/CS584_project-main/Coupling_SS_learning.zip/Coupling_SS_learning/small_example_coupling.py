import pandas as pd
import glob
import re


# clean speech corpus data
def clean_speech_data(data_to_clean):
    if data_to_clean is not None:
        # used to replace occurrences of a particular sub-string with another sub-string.
        # removing paragraph numbers
        cleanTxt = re.sub('[0-9]+.\t','',str(data_to_clean))
        # From cleanTxt -> removing new line characters
        cleanTxt = re.sub('\n ','',str(cleanTxt))
        cleanTxt = re.sub('\n',' ',str(cleanTxt))
        # From cleanTxt -> removing apostrophes
        cleanTxt = re.sub("'s",'',str(cleanTxt))
        # From cleanTxt -> removing hyphens
        cleanTxt = re.sub("-",' ',str(cleanTxt))
        cleanTxt = re.sub("— ",'',str(cleanTxt))
        # From cleanTxt -> removing quotation marks
        cleanTxt = re.sub('\"','',str(cleanTxt))
        # From cleanTxt -> removing salutations
        cleanTxt = re.sub("Mr\.",'Mr',str(cleanTxt))
        cleanTxt = re.sub("Mrs\.",'Mrs',str(cleanTxt))
        # From cleanTxt -> removing any reference to outside text
        cleanTxt = re.sub("[\(\[].*?[\)\]]", "", str(cleanTxt))
        return cleanTxt


# split corpus
def get_clean_corpus_data(corpus):
    if corpus is not None:
        # split sentences and questions
        # re.split(r'\W+', 'Words, words, words.
        corpus = re.split('[.?]', corpus)
        clean_text_upd = list()
        for idx_c in corpus:
            clean_text_upd.append(idx_c)
        return clean_text_upd

# 20
# Find corpus that has PM of India in it.
import spacy
from spacy.matcher import Matcher
sample_nlp_model = spacy.load('en_core_web_sm', disable=['ner', 'textcat'])
def get_names(corpus):
    if corpus is not None:
        # Pattern
        pattern = [{'LOWER': 'prime'},
                   {'LOWER': 'minister'},
                   {'POS': 'ADP', 'OP': '?'},
                   {'POS': 'PROPN'}]
        list_of_data = list()
        # Create a spacy wordList_names
        wordList_names = sample_nlp_model(corpus)
        # Matcher class object
        matcher = Matcher(sample_nlp_model.vocab)
        # matcher.add() with an ID and a list of patterns
        matcher.add("names", [pattern], on_match=None)
        # With a word-list loaded up using WordList, click in the column whose data you want to match up.
        matches = matcher(wordList_names)
        # Finding patterns in the text
        for idx in range(0, len(matches)):
            # match: id, init, end
            # append token to list
            list_of_data.append(str(wordList_names[matches[idx][1]:matches[idx][2]]))
        # Only keep sentences containing Indian PMs
        for idx in list_of_data:
            if (idx.split()[2] == 'of') and (idx.split()[3] != "India"):
                list_of_data.remove(idx)
        return list_of_data


#25
def check_pattern(corpus):
    if corpus is not None:
        flag = 0
        res_corpus = list()
        new_patterns = [r'\b(?i)'+'plan'+r'\b', r'\b(?i)'+'programme'+r'\b', r'\b(?i)'+'scheme'+r'\b', r'\b(?i)'+'campaign'+r'\b', r'\b(?i)'+'initiative'+r'\b', r'\b(?i)'+'conference'+r'\b', r'\b(?i)'+'agreement'+r'\b', r'\b(?i)'+'alliance'+r'\b']
        # Look for patterns in the text
        for idx in new_patterns:
            if re.search(idx, corpus) != None:
                flag = 1
                break
        return flag


# 184
# To extract initiatives using pattern matching
def all_schemes(corpus, pattern_to_check):
    if corpus is not None:
        if pattern_to_check is not None:
            res_corpus = list()
            wordList = sample_nlp_model(corpus)

            # Initiatives keywords
            keywords = ['agreement', 'conference', 'alliance', 'plan', 'programme', 'scheme', 'initiative', 'campaign']

            # Define pattern to match initiatives names
            new_patterns_2 = [{'POS': 'DET'},
                              {'POS': 'PROPN', 'DEP': 'compound'},
                              {'POS': 'PROPN', 'DEP': 'compound'},
                              {'POS': 'PROPN', 'OP': '?'},
                              {'POS': 'PROPN', 'OP': '?'},
                              {'POS': 'PROPN', 'OP': '?'},
                              {'LOWER': {'IN': keywords}, 'OP': '+'}]

            if pattern_to_check == 0:
                # if return pattern_to_check as a None
                return res_corpus

            # Matcher class object
            obj_matcher = Matcher(sample_nlp_model.vocab)
            # matcher.add() with an ID and a list of patterns
            obj_matcher.add("matching", [new_patterns_2], on_match=None)
            # With a word-list loaded up using WordList, click in the column whose data you want to match up.
            obj_matcher_nlp = obj_matcher(wordList)

            for idx in range(0, len(obj_matcher_nlp)):
                # match with: id, init, end
                init, end = obj_matcher_nlp[idx][1], obj_matcher_nlp[idx][2]
                if wordList[init].pos_ == 'DET':
                    init = init + 1
                # matched sring as string wordlist
                span = str(wordList[init:end])
                if (len(res_corpus) != 0) and (res_corpus[-1] in span):
                    res_corpus[-1] = span
                else:
                    res_corpus.append(span)
            return res_corpus


#207
# Method to extract initiative name
def sent_subtree(corpus):
    if corpus is not None:
        schemers_corpses = list()
        wordList = sample_nlp_model(corpus)
        # pattern match for schemes or initiatives
        name_patterns_3 = [r'\b(?i)' + 'plan' + r'\b',
                           r'\b(?i)' + 'programme' + r'\b',
                           r'\b(?i)' + 'scheme' + r'\b',
                           r'\b(?i)' + 'campaign' + r'\b',
                           r'\b(?i)' + 'initiative' + r'\b',
                           r'\b(?i)' + 'conference' + r'\b',
                           r'\b(?i)' + 'agreement' + r'\b',
                           r'\b(?i)' + 'alliance' + r'\b']
        check = 0
        # if no initiative present in sentence
        for idx in name_patterns_3:
            if re.search(idx, corpus) != None:
                check = 1
                break
        if check == 0:
            return schemers_corpses
        # iterating over sentence words
        for wordIdx in wordList:
            for idx in name_patterns_3:
                # if we get a pattern match
                if re.search(idx, wordIdx.text) != None:
                    word = ''
                    # iterating over token subtree
                    for node in wordIdx.subtree:
                        # only extract the proper nouns
                        if (node.pos_ == 'PROPN'):
                            word += node.text + ' '
                    if len(word) != 0:
                        schemers_corpses.append(word)
        return schemers_corpses

#217
# function to check result percentage for a rule
def check_result(df,out_col):
    if df is not None:
        if out_col is not None:
            N = 0
            for idx in df[out_col]:
                if len(idx)!=0:
                    N = N + 1
            # Derive percentage
            cal = N/len(df)
            cal = cal * 100
            print(cal, "% pattern match")
            return cal


#217
# Function for rule 1: noun(subject), verb, noun(object)
def extraction_method(text):
    if text is not None:
        doc = sample_nlp_model(text)
        obj_res = list()
        for token in doc:
            # If the token is a verb
            if (token.pos_ == 'VERB'):
                obj = ''
                # Only extract noun or pronoun subjects
                for sub_tok in token.lefts:
                    if (sub_tok.dep_ in ['nsubj', 'nsubjpass']) and (sub_tok.pos_ in ['NOUN', 'PROPN', 'PRON']):
                        # Add subject to the obj
                        obj += sub_tok.text
                        # Save the root of the word in obj
                        obj += ' ' + token.lemma_
                        # Check for noun or pronoun direct objects
                        for sub_tok in token.rights:
                            # Save the object in the obj
                            if (sub_tok.dep_ in ['dobj']) and (sub_tok.pos_ in ['NOUN', 'PROPN']):
                                obj += ' ' + sub_tok.text
                                obj_res.append(obj)
        return obj_res


#232
def get_text(corpus):
    if corpus is not None:
        res_list = []
        # iterate over tokens
        for idx in sample_nlp_model(corpus):
            common_phrase = ''
            # if the word is a subject noun or an object noun
            if (idx.pos_ == 'NOUN')\
                and (idx.dep_ in ['dobj','pobj','nsubj','nsubjpass']):
                # iterate over the children nodes
                for idxChild in idx.children:
                    # if word is an adjective or has a compound dependency
                    if (idxChild.pos_ == 'ADJ') or (idxChild.dep_ == 'compound'):
                        common_phrase += idxChild.text + ' '
                if len(common_phrase)!=0:
                    common_phrase += idx.text
            if  len(common_phrase)!=0:
                res_list.append(common_phrase)
        return res_list

#252
def get_text_mod(corpus,compare):
    if corpus is not None:
        if compare is not None:
            common_phrase = ''
            obj = sample_nlp_model(corpus)
            for idx in obj:
                if idx.i == compare:
                    for idxChild in idx.children:
                        if (idxChild.pos_ == 'ADJ'):
                            common_phrase += ' '+idxChild.text
                    break
            return common_phrase

#255
# sample_nlp_model
def rule1_mod(corpus):
    if corpus is not None:
        res_list = list()
        obj = sample_nlp_model(corpus)
        for idx in obj:
            # root word
            if (idx.pos_=='VERB'):
                common_phrase =''
                for index in idx.lefts:
                    if (index.dep_ in ['nsubj','nsubjpass']):
                        if(index.pos_ in ['NOUN','PROPN','PRON']):
                            common_phrase = common_phrase + get_text_mod(corpus,index.i) + ' ' + index.text
                            common_phrase = common_phrase + ' ' + idx.lemma_
                            for index in idx.rights:
                                if (index.dep_ in ['dobj']):
                                    if(index.pos_ in ['NOUN','PROPN']):
                                        common_phrase = common_phrase + get_text_mod(corpus,index.i)+ ' ' +index.text
                                        res_list.append(common_phrase)
        return res_list

#274
def rule_on_preposition(text):
    if text is not None:
        res_list = list()
        obj = sample_nlp_model(text)
        for idx in obj:
            # look for prepositions
            if idx.pos_=='ADP':
                common_phrase = ''
                # if its head word is a noun
                if idx.head.pos_=='NOUN':
                    # append noun and preposition to phrase
                    common_phrase = common_phrase + idx.head.text
                    common_phrase = common_phrase + ' ' + idx.text
                    # check the nodes to the right of the preposition
                    for idxRight in idx.rights:
                        # append if it is a noun or proper noun
                        if (idxRight.pos_ in ['NOUN','PROPN']):
                            common_phrase = common_phrase + ' ' +idxRight.text
                    if len(common_phrase)>2:
                        res_list.append(common_phrase)
        return res_list


#357
def pre_processing_data(corpus, start):
    if corpus is not None:
        if start is not None:
            idx = sample_nlp_model(corpus)[start]
            current_phrase = ''
            for idxChild in idx.children:
                if (idxChild.dep_ in ['compound','amod']):
                    current_phrase = current_phrase + idxChild.text + ' '
            current_phrase = current_phrase + idx.text
            return current_phrase


#358
def post_processing_match(text):
    if text is not None:
        res_list_post_processing = list()
        obj = sample_nlp_model(text)
        for idx in obj:
            if idx.pos_=='ADP':
                common_phrase = ''
                if idx.head.pos_=='NOUN':
                    append = pre_processing_data(text, idx.head.i)
                    if len(append)!=0:
                        common_phrase = common_phrase + append
                    else:
                        common_phrase = common_phrase + idx.head.text
                    common_phrase = common_phrase + ' ' + idx.text
                    for idxRight in idx.rights:
                        if (idxRight.pos_ in ['NOUN','PROPN']):
                            temp_phrase = ''
                            # appended rule
                            append = pre_processing_data(text, idxRight.i)
                            if len(append)!=0:
                                temp_phrase = temp_phrase + ' ' + append
                            else:
                                temp_phrase = temp_phrase + ' ' + idxRight.text
                            common_phrase = common_phrase + temp_phrase
                    if len(common_phrase)>2:
                        res_list_post_processing.append(common_phrase)
        return res_list_post_processing


def get_information_retrival():
    ## [1]
    sample_nlp_model = spacy.load('en_core_web_sm', disable=['ner', 'textcat'])
    sample_text = "Coupling Semi-Supervised Learning sample sentence of Categories and Relations"
    wordList = sample_nlp_model(sample_text)
    for words in wordList:
        print(words.text, '->', words.pos_)

    ##[2]
    sample_nlp_model = spacy.load('en_core_web_sm', disable=['ner', 'textcat'])
    sample_text = "Coupling Semi-Supervised Learning sample sentence of Categories and Relations"
    wordList = sample_nlp_model(sample_text)
    for words in wordList:
        print(words.text, '->', words.pos_)

    ## [3]
    sample_text = "I am Harsh Patel, i love european food"
    wordList = sample_nlp_model(sample_text)
    for idx in wordList:
        print(idx.text, '->', idx.pos_)

    ##5
    for idx in wordList:
        if (idx.dep_ == 'nsubj'):  #  idx.dep_ == 'nsubj'
            print("extract subject:= ", idx.text)
        elif (idx.dep_ == 'dobj'):  # idx.dep_ == 'dobj'
            print("\nextract object:= ", idx.text)
    dir_path = glob.glob('TXT/Session*')
    dataFrame = pd.DataFrame(columns={'Country', 'Speech', 'Session', 'Year'})
    idx = 0
    for directory in dir_path:
        print("directory name: = ", directory)
        # Get all the data start with in USA*.txt
        text_raw = glob.glob(directory + '/IND*.txt')
        with open(text_raw[0], encoding='utf8') as file: # print(text_raw[0].split('_')[2].split('-')[-1].split('/')[-1])
            dataFrame.loc[idx, 'Speech'] = file.read()             # data of speech
            dataFrame.loc[idx, 'Year'] = text_raw[0].split('_')[-1].split('.')[0]             # data of year
            dataFrame.loc[idx, 'Session'] = text_raw[0].split('_')[-2]             # data of session
            dataFrame.loc[idx, 'Country'] = text_raw[0].split('_')[2].split('-')[-1].split('/')[-1]             # data of country
            idx = idx + 1             # idx = idx + 1
    print(dataFrame.head())

    ## 9
    dataFrame['Speech_clean'] = dataFrame['Speech'].apply(clean_speech_data)
    print("\n1. dataFrame file after pre-process cleaning of the data: = \n", dataFrame.head())
    print(" #######################################################################################################################################")

    # 10
    dataFrame['sent'] = dataFrame['Speech_clean'].apply(get_clean_corpus_data)
    print("\n2. dataFrame file after cleaning the corpus data: = \n", dataFrame.head())
    print(" #######################################################################################################################################")

    # 17
    # Create a dataframe containing sentences <- columns=['Sent','Year','Len']
    dataFrame2 = pd.DataFrame(columns=['Sent', 'Year', 'Len'])
    # List of sentences for new df
    df_row_list = list()
    # for-loop to go over the df speeches
    for idx in range(len(dataFrame)):
        # for-loop to go over the sentences in the speech
        for sent in dataFrame.loc[idx, 'sent']:
            df_row_list.append({'Year': dataFrame.loc[idx, 'Year'], 'Sent': sent, 'Len': len(sent.split())})  # Append dictionary to list
    # Create the new df
    dataFrame2 = pd.DataFrame(df_row_list)
    print("\n3. dataFrame file after cleaning the corpus data: = \n", dataFrame2.head())
    print("\n4. dataFrame shape: = ", dataFrame2.shape)
    print(" #######################################################################################################################################")

    # 21
    # Get result of get_names()
    dataFrame2['PM_Names'] = dataFrame2['Sent'].apply(get_names)

    #22
    # look at sentences for a specific year
    # Map range of df2
    for idx in range(len(dataFrame2)):
        # Map index where year = 1980
        if dataFrame2.loc[idx, 'Year'] in ['1980']:
            # GEt the PM NAMES
            if len(dataFrame2.loc[idx, 'PM_Names']) != 0:
                # Print the sentence.
                print('->', dataFrame2.loc[idx, 'Sent'], '\n')

    #23
    num_of_occurrence = 0
    for idx in range(len(dataFrame2)):
        if len(dataFrame2.loc[idx, 'PM_Names']) != 0:
            num_of_occurrence = num_of_occurrence + 1
    print("RESULT: = ", num_of_occurrence, "out of", dataFrame2.shape[0], "occurrence")

    #25
    dataFrame2['Check_Schemes'] = dataFrame2['Sent'].apply(check_pattern)

    #26
    num_of_occurrence_1 = 0
    for i in range(len(dataFrame2)):
        if dataFrame2.loc[i, 'Check_Schemes'] == 1:
            num_of_occurrence_1 = num_of_occurrence_1 + 1
    print("RESULT for new_patterns: = ", num_of_occurrence_1, "out of", dataFrame2.shape[0], "occurrence")

    # 184
    # return all_schemes method
    dataFrame2['Schemes1'] = dataFrame2.apply(lambda x: all_schemes(x.Sent, x.Check_Schemes), axis=1)
    print(dataFrame2['Schemes1'])

    #204
    # Sentences that contain the initiative words
    num_of_occurrence_total_2 = 0
    for idx in range(len(dataFrame2)):
        if len(dataFrame2.loc[idx, 'Schemes1']) != 0:
            num_of_occurrence_total_2 = num_of_occurrence_total_2 + 1
    print("RESULT for new_patterns: = ", num_of_occurrence_total_2, "out of", dataFrame2.shape[0], "occurance")

    # 205
    target_year = '2018'
    for idx in range(len(dataFrame2)):
        if dataFrame2.loc[idx, 'Year'] == target_year:
            if len(dataFrame2.loc[idx, 'Schemes1']) != 0:
                print('->', dataFrame2.loc[idx, 'Year'], ',', dataFrame2.loc[idx, 'Schemes1'], ':')
                print(dataFrame2.loc[idx, 'Sent'])

    #207
    # derive initiatives
    dataFrame2['Schemes2'] = dataFrame2['Sent'].apply(sent_subtree)

    #210
    target_year = '2018'
    for idx in range(len(dataFrame2)):
        if dataFrame2.loc[idx, 'Year'] == target_year:
            if len(dataFrame2.loc[idx, 'Schemes2']) != 0:
                print('->', dataFrame2.loc[idx, 'Year'], ',', dataFrame2.loc[idx, 'Schemes2'], ':')
                print(dataFrame2.loc[idx, 'Sent'])

    #213
    res_list = list()
    for idx in range(len(dataFrame2)):
        sent = dataFrame2.loc[idx, 'Sent']
        if (',' not in sent) and (len(sent.split()) <= 15):
            year = dataFrame2.loc[idx, 'Year']
            length = len(sent.split())
            res_list.append({'Year': year, 'Sent': sent, 'Len': length})
    # df with shorter sentences
    dataframe3 = pd.DataFrame(columns=['Year', 'Sent', "Len"])
    dataframe3 = pd.DataFrame(res_list)
    print("\n5. dataFrame file after cleaning the corpus data: = \n", dataframe3.head())
    print("\n6. dataFrame shape: = ", dataframe3.shape)
    print(" #######################################################################################################################################")

    #221
    # Create a df containing sentence and its output for pd.DataFrame(row_list)
    df_list = list()
    for idx in range(len(dataframe3)):
        df_list.append({'Year': dataframe3.loc[idx, 'Year'], 'Sent': dataframe3.loc[idx, 'Sent'], 'Output': extraction_method(dataframe3.loc[idx, 'Sent'])})
    print("df_rule1:= ", pd.DataFrame(df_list))
    check_result(pd.DataFrame(df_list), 'Output')

    #222
    # Create a df containing sentence and its output for pd.DataFrame(row_list)
    df_list_1 = list()
    for idx in range(len(dataFrame2)):
        df_list_1.append({'Year': dataFrame2.loc[idx, 'Year'], 'Sent': dataFrame2.loc[idx, 'Sent'], 'Output': extraction_method(dataFrame2.loc[idx, 'Sent'])})
    print("df_rule1:= \n", pd.DataFrame(df_list_1))
    new_rule_book = pd.DataFrame(df_list_1)
    check_result(pd.DataFrame(df_list_1), 'Output')

    #223
    # selecting non-empty output rows
    df_show = pd.DataFrame(columns=new_rule_book.columns)
    for idx in range(len(new_rule_book)):
        if len(new_rule_book.loc[idx, 'Output']) != 0:
            df_show = df_show.append(new_rule_book.loc[idx, :])
    # reset the index
    df_show.reset_index(inplace=True)
    df_show.drop('index', axis=1, inplace=True)

    #225
    print("shape of new_rule_book DF:= ", new_rule_book.shape)
    print("shape of df_show DF:= ", df_show.shape)

    #224
    res_verb_dict = dict()
    res_dis_list = list()
    # iterating over all the sentences
    for idx in range(len(df_show)):
        # sentence containing the output
        sentence = df_show.loc[idx, 'Sent']
        # year of the sentence
        year = df_show.loc[idx, 'Year']
        # output of the sentence
        output = df_show.loc[idx, 'Output']
        # iterating over all the outputs from the sentence
        for sent in output:
            # append to list, along with the sentence
            res_dis_list.append({'Sent': sentence, 'Year': year, 'Noun1': sent.split()[:1], 'Verb': sent.split()[1],
                                 'Noun2': sent.split()[2:]})
            # counting the number of sentences containing the verb
            if sent.split()[1] in res_verb_dict:
                res_verb_dict[sent.split()[1]] += 1
            else:
                res_verb_dict[sent.split()[1]] = 1
    df_sep = pd.DataFrame(res_dis_list)
    print("\n7. dataFrame file after cleaning the corpus data: = \n", df_sep.head())
    print("\n8. dataFrame shape: = ", df_sep.shape)
    print(" #######################################################################################################################################")


    #225
    # Sort by top 20
    print(sorted(res_verb_dict.items(), key=lambda idx: (idx[1], idx[0]), reverse=True)[:20])

    #229
    # Get the list of the verb
    print(df_sep[df_sep['Verb'] == 'have'])

    # 230
    # Get the list of the verb
    print(df_sep[df_sep['Verb'] == 'constitute'])

    #233
    # Create a df containing sentence and its output for rule 2
    res_list_1 = list()
    for idx in range(len(dataframe3)):
        res_list_1.append({'Year': dataframe3.loc[idx, 'Year'], 'Sent': dataframe3.loc[idx, 'Sent'], 'Output': get_text(dataframe3.loc[idx, 'Sent'])})
    df_rule2 = pd.DataFrame(res_list_1)
    print("\n9. dataFrame file after cleaning the corpus data: = \n", df_rule2.head())
    print("\n10. dataFrame shape: = ", df_rule2.shape)
    print(" #######################################################################################################################################")

    #235
    # get_text output
    check_result(df_rule2, 'Output')

    # 236
    # Create a df containing sentence and its output for rule 2
    res_list_2 = list()
    for idx in range(len(dataframe3)):
        res_list_2.append({'Year': dataframe3.loc[idx, 'Year'], 'Sent': dataframe3.loc[idx, 'Sent'], 'Output': get_text(dataframe3.loc[idx, 'Sent'])})
    df_rule2_all = pd.DataFrame(res_list_2)
    print("\n11. dataFrame file after cleaning the corpus data: = \n", df_rule2_all.head())
    print("\n12. dataFrame shape: = ", df_rule2_all.shape)
    print(" #######################################################################################################################################")

    #239
    # Selecting non-empty outputs
    df_show2 = pd.DataFrame(columns=df_rule2_all.columns)
    for idx in range(len(df_rule2_all)):
        if len(df_rule2_all.loc[idx, 'Output']) != 0:
            df_show2 = df_show2.append(df_rule2_all.loc[idx, :])
    # Reset the index
    df_show2.reset_index(inplace=True)
    df_show2.drop('index', axis=1, inplace=True)

    #240
    print("df_show2:= \n", df_show2)

    #273
    # Create a df containing sentence and its output for rule 2
    res_list_3 = list()
    for idx in range(len(dataFrame2)):
        res_list_3.append({'Year': dataFrame2.loc[idx, 'Year'], 'Sent': dataFrame2.loc[idx, 'Sent'], 'Output': rule1_mod(dataFrame2.loc[idx, 'Sent'])})
    df_final = pd.DataFrame(res_list_3)
    check_result(pd.DataFrame(res_list_3), 'Output')
    print("\n13. dataFrame file after cleaning the corpus data: = \n", df_final.head())
    print("\n14. dataFrame shape: = ", df_final.shape)
    print(" #######################################################################################################################################")

    #275
    res_list_4 = list()
    for idx in range(len(dataframe3)):
        res_list_4.append({'Year': dataframe3.loc[idx, 'Year'], 'Sent': dataframe3.loc[idx, 'Sent'], 'Output': rule_on_preposition(dataframe3.loc[idx, 'Sent'])})
    df_rule_on_preposition = pd.DataFrame(res_list_4)
    check_result(pd.DataFrame(res_list_4), 'Output')
    print("\n15. dataFrame file after cleaning the corpus data: = \n", df_rule_on_preposition.head())
    print("\n16. dataFrame shape: = ", df_rule_on_preposition.shape)
    print( " #######################################################################################################################################")

    #278
    res_list_5 = list()
    for idx in range(len(dataFrame2)):
        res_list_5.append({'Year': dataFrame2.loc[idx, 'Year'], 'Sent': dataFrame2.loc[idx, 'Sent'], 'Output': rule_on_preposition(dataFrame2.loc[idx, 'Sent'])})
    df_rule_on_preposition_final = pd.DataFrame(res_list_5)
    check_result(pd.DataFrame(res_list_5), 'Output')
    print("\n17. dataFrame file after cleaning the corpus data: = \n", df_rule_on_preposition_final.head())
    print("\n18. dataFrame shape: = ", df_rule_on_preposition_final.shape)
    print(" #######################################################################################################################################")

    #281
    # Selecting non-empty outputs
    df_show3 = pd.DataFrame(columns=df_rule_on_preposition_final.columns)
    for idx in range(len(df_rule_on_preposition_final)):
        if len(df_rule_on_preposition_final.loc[idx, 'Output']) != 0:
            df_show3 = df_show3.append(df_rule_on_preposition_final.loc[idx, :])
    # Reset the index
    df_show3.reset_index(inplace=True)
    df_show3.drop('index', axis=1, inplace=True)
    print("\n19. df_rule_on_preposition_final.shape: = \n", df_rule_on_preposition_final.shape)
    print("\n20. df_show3.shape: = ", df_show3.shape)
    print(" #######################################################################################################################################")

    #314
    res_preposition_dict = dict()
    res_dis_list_upd = list()
    # iterating over all the sentences
    for idx in range(len(df_show3)):
        obj = df_show3.loc[idx, 'Output']
        # iterating over all the outputs from the sentence
        for idx_obj in obj:
            # append to list, along with the sentence
            res_dis_list_upd.append(
                {'Sent': df_show3.loc[idx, 'Sent'], 'Year': df_show3.loc[idx, 'Year'], 'Noun1': idx_obj.split()[0],
                 'Preposition': idx_obj.split()[1], 'Noun2': idx_obj.split()[2:]})
            # counting the number of sentences containing the verb
            if idx_obj.split()[1] in res_preposition_dict:
                res_preposition_dict[idx_obj.split()[1]] = res_preposition_dict[idx_obj.split()[1]] + 1
            else:
                res_preposition_dict[idx_obj.split()[1]] = 1
    final_data_list = pd.DataFrame(res_dis_list_upd)
    print("\n21. df_rule_on_preposition_final.shape: = \n", final_data_list.shape)
    print("\n22. df_show3.shape: = ", final_data_list.shape)
    print(" #######################################################################################################################################")

    #318
    print("final_data_list with ['Preposition']=='than':= \n", final_data_list[final_data_list['Preposition']=='than'])

    # 319
    print("final_data_list with ['Preposition'] == 'about']:= \n", final_data_list[final_data_list['Preposition'] == 'about'])

    # 381
    # create a df containing sentence and its output for rule 3
    final_res_list = list()
    # df2 contains all the sentences from all the speeches
    for idx in range(len(df_show3)):
        final_res_list.append({'Year': df_show3.loc[idx, 'Year'], 'Sent': df_show3.loc[idx, 'Sent'], 'Output': post_processing_match(df_show3.loc[idx, 'Sent'])})
    df_rule3_final = pd.DataFrame(final_res_list)
    print("\n23. df_rule_on_preposition_final.shape: = \n", df_rule3_final.shape)
    print("\n24. df_show3.shape: = ", df_rule3_final.shape)
    print("df_rule3_final:= \n", df_rule3_final)
    print(" #######################################################################################################################################")

    # 378
    # After n+1 iteration,
    res_preposition_dict_new = dict()
    res_dis_list_upd_new = list()

    # iterating over all the sentences
    for idx in range(len(df_rule3_final)):
        obj_new = df_rule3_final.loc[idx, 'Output']
        # iterating over all the outputs from the sentence
        for idx_obj_new in obj_new:
            # append to list, along with the sentence
            res_dis_list_upd_new.append(
                {'Sent': df_rule3_final.loc[idx, 'Sent'], 'Year': df_rule3_final.loc[idx, 'Year'],
                 'Noun1': idx_obj_new[0], 'Preposition': idx_obj_new[1], 'Noun2': idx_obj_new[2:]})
            # counting the number of sentences containing the verb
            if idx_obj_new[1] in res_preposition_dict_new:
                res_preposition_dict_new[idx_obj_new[1]] = res_preposition_dict_new[idx_obj_new[1]] + 1
            else:
                res_preposition_dict_new[idx_obj_new[1]] = 1
    df_sep_final_final_3 = pd.DataFrame(res_dis_list_upd_new)

    # print out df_sep3_final_final
    print("final_data_list:= \n", final_data_list)



