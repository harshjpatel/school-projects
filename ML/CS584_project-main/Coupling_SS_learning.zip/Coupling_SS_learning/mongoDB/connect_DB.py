import os

print(os.path.dirname(os.path.abspath(__file__)))

from config.get_config import MONGO_DB_URL
from pymongo import MongoClient as MC
from urlService.services.utils.logger import logger as lg
from pymodm.connection import connect

# We need to check if MongoDB works or not.
def get_mongo_db():
    try:
        mongoDB = MC(MONGO_DB_URL)
        mongoDB.server_info()
        connect(MONGO_DB_URL)
        lg.info('The connection is successful to: ' + MONGO_DB_URL)
    except:
        lg.error('The connection is not successful to: ' + MONGO_DB_URL)
        exit()

