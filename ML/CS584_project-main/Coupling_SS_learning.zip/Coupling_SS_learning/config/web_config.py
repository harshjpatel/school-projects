config = {
    "title": "Coupled Pattern Learner",
    "lib": {
        "css": [
            "../node_modules/materialize-css/dist/css/materialize.min.css",
            "../node_modules/font-awesome/css/font-awesome.css",
        ],
        "js": [
            "../node_modules/materialize-css/dist/js/materialize.min.js",
            "../node_modules/jquery/dist/jquery.js",
            "../node_modules/popper.js/dist/popper.js",
            "../node_modules/bootstrap/dist/js/bootstrap.js",
            "../node_modules/angular/angular.js",
            "../node_modules/angular-ui-router/release/angular-ui-router.js",
            "../node_modules/angular-resource/angular-resource.js",
            "../node_modules/angular-animate/angular-animate.js",
            "../node_modules/angular-aria/angular-aria.js",
            "../node_modules/angular-messages/angular-messages.js"
        ]
    },
    "css": [
        "modules/*/css/*.css"
    ],
    "js": [
        "modules/core/app/config.js",
        "modules/core/app/init.js",
        "modules/**/*.js",
        "modules/*/controller/*.js",
        "modules/*/routes/*.js",
        "modules/*/services/*.js"
    ],
    "views": [
         "modules/*/views/*.html"
    ]
}