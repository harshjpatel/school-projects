import glob, os
from typing import Union
from web_config import config
from config.get_config import STATIC_FOLDER

def glob_path(relative_paths):
    globbed_paths: list[Union[int, bytes, str]] = list()
    for relative_path in relative_paths:
        relative_path = os.path.join(STATIC_FOLDER, relative_path)
        paths = [path.replace('\\', '/')[len(STATIC_FOLDER) + 1:] for path in glob.glob(relative_path)]
        globbed_paths.extend(paths)
    return globbed_paths

def initialize_files(config):
    modified_config = {}
    modified_config['title'] = config['title']
    modified_config['css'] = []
    modified_config['js'] = []
    modified_config['css'] = config['lib']['css']
    modified_config['js'] = config['lib']['js']
    modified_config['css'].extend(glob_path(config['css']))
    modified_config['js'].extend(glob_path(config['js']))
    return modified_config

if __name__ == '__main__':
    files = initialize_files(config)