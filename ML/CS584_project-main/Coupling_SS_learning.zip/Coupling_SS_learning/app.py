from config.get_config import STATIC_FOLDER
from flask import Flask
from urlService.controllers import start_coupling_SS_learning
from mongoDB import connect_DB
from urlService.services.utils.logger import logger as lg
from urlService.controllers.pattern import pattern_learn_controller
from urlService.models.pattern import pattern_learner_model
from urlService.services.utils.constants import NAME
from urlService.services.category import category_last_promoted_service
from urlService.services.relation import relation_list_promoted_service
import small_example_coupling


if __name__ == '__main__':
    lg.info('Trying to connect Mongo Client Database...')
    connect_DB.get_mongo_db()
    # frontend = Blueprint('frontend', __name__,
    #                      template_folder='templates',
    #                      static_folder='static')

    # app = Flask(__name__, template_folder=STATIC_FOLDER, static_folder=STATIC_FOLDER)
    start_coupling_SS_learning(Flask(__name__, template_folder=STATIC_FOLDER, static_folder=STATIC_FOLDER))

    data = {
        'name': 'LEARNER - 2',
        'corpus': '5ab4e4295d76c925c4b90275'
    }

    pattern_learn_controller.pattern_learn_service(data)

    # cblLearner object as learner model of CBLAlgorithm
    cblLearner = pattern_learner_model.CBLAlgorithm()

    # small_example
    small_example_coupling.get_information_retrival()

    # Get all cblLearner.last_promoted_categories and cblLearner.last_promoted_relations
    if not list(pattern_learner_model.Coupling_SS_Learning_Relation_Model.objects.raw({'_id': data[NAME]})):
        cblLearner.name = data[NAME]
        cblLearner.iter = 0
        cblLearner.last_promoted_categories = category_last_promoted_service.list_every_data()
        cblLearner.last_promoted_relations = relation_list_promoted_service.relation_list_every_data_service()